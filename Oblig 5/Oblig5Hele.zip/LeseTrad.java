import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Scanner;
import java.util.concurrent.CountDownLatch;


//Den samme LeseTrad klassen som fra tidligere del-løsninger.


public class LeseTrad implements Runnable {

    private String filnavn;
    private Monitor2 monitor;
    private CountDownLatch minBarriere;

    public LeseTrad(String filnavn, Monitor2 monitor, CountDownLatch minBarriere){
        this.filnavn = filnavn;
        this.monitor = monitor;
        this.minBarriere = minBarriere;
    }

    @Override
    public void run() {

        System.out.println("Traaden leser inn: " + filnavn);

        try{

            File fil = new File(filnavn);
            Scanner sc = new Scanner(fil);
            String linje = "";
            int subsekvensLengde = 3;
            HashMap<String,Subsekvens> subsekvenser = new HashMap<>();

            while(sc.hasNextLine()){
                linje = sc.nextLine();
                String[] biter = linje.split("");

                if(biter.length >= subsekvensLengde){

                    for (int i = 0; i < biter.length -2; i++){
                        String subsekvens = biter[i] + biter[i+1] + biter[i+2];     
                        Boolean eksisterer = false;
                        
                        if(subsekvenser.containsKey(subsekvens)){
                                eksisterer = true;
                        }

                        if(!eksisterer){
                            Subsekvens nySubsekvens = new Subsekvens(subsekvens);
                            nySubsekvens.oekAntall(1);
                            subsekvenser.put(subsekvens, nySubsekvens);
                    }
                }
            }
        }
        
        monitor.settInnHashMap(subsekvenser);
        monitor.signaliserFerdig();
        minBarriere.countDown();
        
        } catch(FileNotFoundException e){
            System.out.println("Fant ikke filen: " + filnavn);
            
        }

    }
}