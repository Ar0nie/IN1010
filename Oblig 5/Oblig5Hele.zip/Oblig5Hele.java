import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Map.Entry;
import java.util.concurrent.CountDownLatch;

//Den siste main traaden Oblig5Hele. 

public class Oblig5Hele {
    
    public static void main(String[] args) throws FileNotFoundException {
        
        String mappe;
        mappe = args[0];

        String fil = "";
        Scanner sc = new Scanner(new File(mappe + "/" + "metadata.csv"));           
        File antFiler = new File(mappe);
        File[] filListe = antFiler.listFiles();

        ArrayList<String> filerInfisert = new ArrayList<>();
        ArrayList<String> filerIkkeInfisert = new ArrayList<>();

        String linje = "";

        //Indelling av filer infisert og ikke infisert:

        while(sc.hasNextLine()){
            linje = sc.nextLine();
            String[] biter = linje.strip().split(",");
            String filNavn = biter[0];
            String status = biter[1];
            if(status.equals("True")){
                filerInfisert.add(filNavn);
            } else if (status.equals("False")){
                filerIkkeInfisert.add(filNavn);
            }
        }

         // Opretter en felles CountDownLatch for infisert og ikke infiserte filer.

        int countDown = filListe.length - 1;
        CountDownLatch nedTelling= new CountDownLatch(countDown);

        SubsekvensRegister infisert = new SubsekvensRegister(true);
        Monitor2 infisertMonitor = new Monitor2(infisert,filerInfisert.size() + filerInfisert.size()-1);

        SubsekvensRegister ikkeInfisert = new SubsekvensRegister(false);
        Monitor2 ikkeInfisertMonitor = new Monitor2(ikkeInfisert,filerIkkeInfisert.size() + filerIkkeInfisert.size()-1);
        

        // Leser inn filerInfisert
        for(String filNavnInfisert : filerInfisert){
            fil = (mappe + "/" + filNavnInfisert);
            LeseTrad filLeserInfisert = new LeseTrad(fil,infisertMonitor,nedTelling);
            Thread nyTraad = new Thread(filLeserInfisert);
            nyTraad.start();
        }
        
        // Leser inn filerIkkeInfisert
        for(String filNavnIkke : filerIkkeInfisert){
           fil = (mappe + "/" + filNavnIkke);
           LeseTrad filLeserIkke = new LeseTrad(fil,ikkeInfisertMonitor,nedTelling);
           Thread nyTraad = new Thread(filLeserIkke);
           nyTraad.start();
        }

        CountDownLatch nedTellingInfisert = new CountDownLatch(filerInfisert.size()-1);
        CountDownLatch nedTellingIkkeInfisert = new CountDownLatch(filerIkkeInfisert.size()-1);

        // CountDownLatcher for infiserte og ikke infiserte filer.


        //fletter infiserte filer
        for(int i = 0; i < filerInfisert.size()-1; i++){
            Thread t = new Thread(new FletteTrad(infisertMonitor, nedTellingInfisert));
            t.start();
        }
        
        // //fletter ikke infiserte filer
        for(int i = 0; i < filerIkkeInfisert.size()-1; i++){
            FletteTrad fletter = new FletteTrad(ikkeInfisertMonitor, nedTellingIkkeInfisert);
            Thread traad = new Thread(fletter);
            traad.start();
        }
        
        //Barriere som venter til alle filer er flettet og deretter gir tilbakemelding om at alt av fletting og innlesing er ferdig.

        try{
            nedTelling.await();
            nedTellingIkkeInfisert.await();
            nedTellingInfisert.await();
        } catch(InterruptedException e){
            System.out.println();
        }
        
        System.out.println();
        System.out.println("Alle HashMaps ikke infiserte flettet...");
        System.out.println("Flettet infiserte filer.. ");
        System.out.println();

        HashMap<String,Integer> flestForekomsterRelativt = new HashMap<>();
        HashMap<String,Subsekvens> infisertHash = infisertMonitor.hentFlette();
        HashMap<String,Subsekvens> ikkeInfisertHash = ikkeInfisertMonitor.hentFlette();

        int infisertAnt;
        int ikkeInfisertAnt;
        int flereForekomsterEnn = 7;
        int diff;
    
        //Sjekker forekomsten av ulike subsekvenser og sjekker hvilke subsekvenser som forekom flest ganger hos infiserte pasienter oppimot ikke infiserte.
        
        for(Entry<String,Subsekvens> entry : infisertHash.entrySet()){
            String key = entry.getKey();
            if(infisertHash.containsKey(key) && ikkeInfisertHash.containsKey(key)){
                infisertAnt = infisertHash.get(key).hentAntall();
                ikkeInfisertAnt = ikkeInfisertHash.get(key).hentAntall();
                diff = infisertAnt - ikkeInfisertAnt;
                if(diff >= flereForekomsterEnn){
                    flestForekomsterRelativt.put(key, diff);
                }
            }
        }

        System.out.println("Antall filer fra infiserte lest inn og flettet: " + filerInfisert.size());
        System.out.println("Antallet filer fra ikke infiserte lest inn og fletet: " + filerIkkeInfisert.size());
        System.out.println();

        //kjorer ut informasjon til brukeren om flest forekomster.

        for(Entry<String,Integer> entry : flestForekomsterRelativt.entrySet()){
            String key = entry.getKey();
            Integer value = entry.getValue();
            System.out.println("Subsekvensen: " + key + ", forekomm: " + value + ", flere ganger hos infiserte enn ikke infiserte.");
        }
        System.exit(-1);
    }
}