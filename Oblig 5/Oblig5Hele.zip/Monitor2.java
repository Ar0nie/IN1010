import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.locks.*;


public class Monitor2 {

    private SubsekvensRegister beholder;
    private Lock laas = new ReentrantLock();
    private Lock fletteLaas = new ReentrantLock();
    private Condition ikkeTom = laas.newCondition();
    private int filer;
    private int filerLest = 0;
    private boolean erFerdig = false;

   


    public Monitor2(SubsekvensRegister beholder, int antallFiler){
        this.beholder = beholder;
        antallFiler = filer;
    }

    public void settInnHashMap(HashMap<String,Subsekvens> nyHash){
        laas.lock();
        try {
            beholder.settInnHashMap(nyHash);
            ikkeTom.signalAll();
        } finally {
            laas.unlock();
        }
    }

    public void signaliserFerdig(){
        laas.lock();
        try {
            filerLest++;
            if(filer == filerLest){
                erFerdig = true;
            }
        } finally {
            laas.unlock();
        }
    }
    public void settInnFlettet(HashMap<String,Subsekvens> nyHash){ 
        fletteLaas.lock();
        try {
            beholder.settInnHashMap(nyHash);
   
        } finally {
            fletteLaas.unlock();
        }
    }

    public ArrayList<HashMap<String,Subsekvens>> hentUtTo(){
        
            laas.lock();
            try {

              while (hentAntMaps() < 2) {
                if (erFerdig) {
                    return null;
                }

                ikkeTom.await();
            }

              ArrayList<HashMap<String,Subsekvens>> sammenSlaa = new ArrayList<>();
              sammenSlaa.add(beholder.hentFlette());
              sammenSlaa.add(beholder.hentFlette());
        
              return sammenSlaa;

            } catch (InterruptedException e) {
              System.out.println();
              System.exit(-1);
            } finally {
              laas.unlock();
        }
        
            return null;
    }
    

    public HashMap<String, Subsekvens> hentFlette(){
        laas.lock();
        try {
            return beholder.hentFlette();
        } finally{
            laas.unlock();
        }
    }


    public int hentAntMaps(){
        laas.lock();
        try{
            return beholder.hentAntMaps();
        } finally{
            laas.unlock();
        }
    }
}


