import java.util.ArrayList;
import java.util.HashMap;



public class SubsekvensRegister {
    
    private ArrayList<HashMap<String, Subsekvens>> hashBeholder = new ArrayList<>();
    private boolean infisert;

    public SubsekvensRegister(boolean infisert){
        this.infisert = infisert;
    }

    public boolean hentStatus(){
        return infisert;
    }

    public void settInnHashMap(HashMap<String,Subsekvens> nyHash){
        hashBeholder.add(nyHash);
    }

    public void settInnHashMap(HashMap<String, Subsekvens> subsekvens, int index){
        hashBeholder.add(index,subsekvens);
    }

    public ArrayList<HashMap<String, Subsekvens>> hentHashBeholder(){
        return hashBeholder;
    }

    public HashMap<String, Subsekvens> hentFlette(){
        return hashBeholder.remove(0);
    }

    public int hentAntMaps(){
        return hashBeholder.size();
    }
}
