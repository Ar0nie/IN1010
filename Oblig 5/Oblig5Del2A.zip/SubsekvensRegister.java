import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;


public class SubsekvensRegister {
    
    private ArrayList<HashMap<String, Subsekvens>> hashBeholder = new ArrayList<>();

    public void settInnHashMap(HashMap<String,Subsekvens> nyHash){
        hashBeholder.add(nyHash);
    }

    public void settInnHashMap(HashMap<String, Subsekvens> subsekvens, int index){
        hashBeholder.add(index,subsekvens);
    }

    public ArrayList<HashMap<String, Subsekvens>> hentHashBeholder(){
        return hashBeholder;
    }

    public void fjernMap(int index){
        hashBeholder.remove(index);
    }
    public HashMap<String,Subsekvens> hentMap(int index){
        return hashBeholder.get(index);
    }

    public HashMap<String, Subsekvens> hentFlette(){
        return hashBeholder.get(0);
    }

    public int hentAntMaps(){
        return hashBeholder.size();
    }

    public static HashMap fletting(HashMap<String, Subsekvens> en, HashMap<String,Subsekvens> to){

        HashMap<String,Subsekvens> sammenslått = new HashMap<>();

        try {
            
            for(Entry<String, Subsekvens> entry : en.entrySet()){
                String key = entry.getKey();
                Subsekvens value = entry.getValue();
                sammenslått.put(key,value);
            }
            
            for(Entry<String,Subsekvens> entry : to.entrySet()){
                String key = entry.getKey();
                Subsekvens value = entry.getValue();

                if(sammenslått.containsKey(key)){
                    sammenslått.get(key).oekAntall(1);

                } else if(!sammenslått.containsKey(key)){
                    sammenslått.put(key,value);
                }
            }

        } 

        catch (IndexOutOfBoundsException e) {
           
           return sammenslått;        

        }
        
        
        return sammenslått;   
    } 
}
