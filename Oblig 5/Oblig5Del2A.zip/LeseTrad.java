import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Scanner;
import java.util.concurrent.CountDownLatch;

//Traadklassen LeseTrad. Hver traad innehar en monitor, en CountDownLatch og et filnavn som leses inn.

public class LeseTrad implements Runnable {

    private String filnavn;
    private Monitor1 monitor;
    private CountDownLatch minBarriere;

    //Konstruktoor med instansariabler som tilordnes verdi.

    public LeseTrad(String filnavn, Monitor1 monitor,CountDownLatch minBarriere){
        this.filnavn = filnavn;
        this.monitor = monitor;
        this.minBarriere = minBarriere;
    }

    //Dette er den metoden vi benyttet for fil-innlesing fra tidligere, overfoort til run() metoden for LeseTrad.
    //Hovedforskjellen er at nytt innhold for subsekvensregister har monitor objektet vaart som mellomledd for aa kontroller tilgang.

    @Override
    public void run() {
        System.out.println("Traaden behandler " + filnavn);
        try{
            File fil = new File(filnavn);
            Scanner sc = new Scanner(fil);
            String linje = "";
            int subsekvensLengde = 3;
            HashMap<String,Subsekvens> subsekvenser = new HashMap<>();

            while(sc.hasNextLine()){
                linje = sc.nextLine();
                String[] biter = linje.split("");

                if(biter.length >= subsekvensLengde){

                    for (int i = 0; i < biter.length -2; i++){
                        String subsekvens = biter[i] + biter[i+1] + biter[i+2];     
                        Boolean eksisterer = false;
                        
                        if(subsekvenser.containsKey(subsekvens)){
                                eksisterer = true;
                        }

                        if(!eksisterer){
                            Subsekvens nySubsekvens = new Subsekvens(subsekvens);
                            nySubsekvens.oekAntall(1);
                            subsekvenser.put(subsekvens, nySubsekvens);
                    }
                }
            }
        }

        //For hver gjennomkjoring av run() vil countDown på den tilhorende CountDownLatchen gjennomfores.

        monitor.settInnHashMap(subsekvenser);
        minBarriere.countDown();
        
        } catch(FileNotFoundException e){
            System.out.println("Fant ikke filen: " + filnavn);
            
        }
    }
}