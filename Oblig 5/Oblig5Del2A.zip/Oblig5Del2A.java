import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Map.Entry;
import java.util.concurrent.CountDownLatch;

//Oblig5Del2A klassen. Dette er main traaden vaar.

public class Oblig5Del2A{
    public static void main(String[] args) throws FileNotFoundException{

        String mappe;
        mappe = args[0];
        String fil = "";
        String linje = "";
        Scanner sc = new Scanner(new File(mappe + "/" + "metadata.csv"));           //Legg til funksjonalitet slik at man kan legge ved mappenavn selv!
        File antFiler = new File(mappe);
        File[] filListe = antFiler.listFiles();
        SubsekvensRegister beholder = new SubsekvensRegister();
        Monitor1 monitor = new Monitor1(beholder);
        
        //Oppretter en CountDownlatch 

        int countDown = filListe.length -1;
        
        CountDownLatch nedTelling = new CountDownLatch(countDown);

        //Opretter en while lookke for fil-innlesing.

        while(sc.hasNextLine()){
            linje = sc.nextLine();
            String[] biter = linje.strip().split(",");
            fil = (mappe + "/" + biter[0]);
            LeseTrad filLeser = new LeseTrad(fil, monitor, nedTelling);
            Thread nyTraad = new Thread(filLeser);
            nyTraad.start();
        }

        //En barriere som oppheves ved alle ferdige innleste traader. Programmet fungerer uten en slik barriere men, 

        try{
            nedTelling.await();
        } catch(InterruptedException e){
            System.out.println(e.getMessage());
        }

        System.out.println("Alle filer lest inn!");
        System.out.println();

        //Koden nedfor har samme funksjon som den i tidligere hovedprogram.

        for(countDown--; countDown > 0;){
            HashMap<String,Subsekvens> flette = monitor.hentFlette();
            HashMap<String,Subsekvens> sammenSlaa = monitor.hentMap(1);
            HashMap<String,Subsekvens> oppdatertFlette = monitor.fletting(flette, sammenSlaa);
            monitor.fjernMap(1);
            monitor.fjernMap(0);
            monitor.settInnHashMap(oppdatertFlette, 0);
            countDown--;
    }
        
        HashMap<String,Subsekvens> flette = monitor.hentFlette();
        Subsekvens flest = new Subsekvens("ABC");
        
        for(Entry<String, Subsekvens> entry : flette.entrySet()){
            Subsekvens value = entry.getValue();
            int ant = value.hentAntall();
            if(ant > flest.hentAntall()){
                flest = value;
            }
        }

        System.out.println("Subsekvensen med flest forekomster i mappen: " + mappe + ", er: " + flest);
    
    }
}