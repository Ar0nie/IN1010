import java.util.*;
import java.util.concurrent.locks.*;

//Dette er monitor klassen vaar som inneholder et objekt av SubsekvensRegister og en ReentrantLock.
//Klassen har som funksjon å begrense tilgangen til metodekall for ulike traader. Paa denne maaten unngaar vi uonskede feil.

public class Monitor1 {
    
    //Metodene laaser og laaser opp metodekalltilgang for hver traad.

    private static SubsekvensRegister beholder;
    private static Lock laas = new ReentrantLock();

    public Monitor1(SubsekvensRegister beholder){
        this.beholder = beholder;
    }

    public void settInnHashMap(HashMap<String,Subsekvens> nyHash, int index){
        laas.lock();
        try {
            beholder.settInnHashMap(nyHash, index);
        } finally {
            laas.unlock();
        }
    }

    public void settInnHashMap(HashMap<String,Subsekvens> nyHash){
        laas.lock();
        try {
            beholder.settInnHashMap(nyHash);
        } finally {
            laas.unlock();
        }
    }

    public void fjernMap(int index){
        laas.lock();
        try {
            beholder.fjernMap(index);
        } finally {
            laas.unlock();
        }
    }

    public ArrayList<HashMap<String, Subsekvens>> hentHashBeholder(){
        laas.lock();
        try {
            return beholder.hentHashBeholder();
            
        }   finally{
            laas.unlock();
        }
    }

    public HashMap<String, Subsekvens> hentMap(int index){
        laas.lock();
        try {
            return beholder.hentMap(index);
        } finally{
            laas.unlock();
        }
    }

    public HashMap<String, Subsekvens> hentFlette(){
        laas.lock();
        try {
            return beholder.hentFlette();
        } finally{
            laas.unlock();
        }
    }

    public static HashMap<String,Subsekvens> fletting(HashMap<String, Subsekvens> en, HashMap<String,Subsekvens> to){
        laas.lock();
        try{
            return beholder.fletting(en, to);
        } finally {
            laas.unlock();
        }
    }

    public int hentAntMaps(){
        laas.lock();
        try{
            return beholder.hentAntMaps();
        } finally{
            laas.unlock();
        }
    }
}
