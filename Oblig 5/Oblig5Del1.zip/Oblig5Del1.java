import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Map.Entry;

//Hovedprogrammet Oblig5Del1. Dette er main traaden for denne del oppgaven.

public class Oblig5Del1 {
 
    
    public static void main(String[] args) throws FileNotFoundException{

        String mappe;
        mappe = args[0];

        SubsekvensRegister register = new SubsekvensRegister();
       
        String linje = "";
        Scanner sc = new Scanner(new File(mappe + "/" + "metadata.csv"));
        String fil = "";
        
        //Enkel fil-innlesing i while lokke.

        int antFiler = 0;
        while(sc.hasNextLine()){
            linje = sc.nextLine();
            String[] biter = linje.split(",");
            fil = (mappe + "/" + biter[0]);
            register.lesFraFil(fil);
            antFiler++;
        }

        //Fletter filene som har blitt lest inn.
        
        for(antFiler--; antFiler > 0;){
                HashMap<String,Subsekvens> flette = register.hentFlette();
                HashMap<String,Subsekvens> sammenSlaa = register.hentMap(1);
                HashMap<String,Subsekvens> oppdatertFlette = register.fletting(flette, sammenSlaa);
                register.fjernMap(1);
                register.fjernMap(0);
                register.settInnHashMap(oppdatertFlette, 0);
                antFiler--;
        }

        //Finner den subsekvensen med flest forekomster ved å iterere igjennom den siste HashMappen i beholderen vaar.

        HashMap<String,Subsekvens> flette = register.hentFlette();
        Subsekvens flest = new Subsekvens("ABC");
        
        for(Entry<String, Subsekvens> entry : flette.entrySet()){
            Subsekvens value = entry.getValue();
            int ant = value.hentAntall();
            if(ant > flest.hentAntall()){
                flest = value;
            }
        }
        System.out.println("Subsekvensen med flest forekomster i mappen: " + mappe + ", er: " + flest);
}
}