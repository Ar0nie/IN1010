import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Map.Entry;
import java.io.File;
import java.io.FileNotFoundException;

//Dette er beholderklassen vaar SubsekvensRegister. Dette er en ArrayList som inneholder HashMaps. Har et visst antall 

public class SubsekvensRegister{
    
    public static ArrayList<HashMap> hashBeholder = new ArrayList<>();
    
    public static void settInnHashMap(HashMap<String, Subsekvens> subsekvens){
        hashBeholder.add(subsekvens);
    }

    public void settInnHashMap(HashMap<String, Subsekvens> subsekvens, int index){
        hashBeholder.add(index,subsekvens);
    }

    //Metode for fil-innlesing. Returnerer HashMappen som fil-innlesingen resulterer i.

    public static HashMap<String,Subsekvens> lesFraFil(String filnavn) throws FileNotFoundException{

        File fil = new File(filnavn);
        Scanner sc = new Scanner(fil);
        String linje = "";
        int subsekvensLengde = 3;
        HashMap<String,Subsekvens> subsekvenser = new HashMap<>();

        while(sc.hasNextLine()){
            linje = sc.nextLine();
            String[] biter = linje.split("");

            if(biter.length >= subsekvensLengde){

                for (int i = 0; i < biter.length -2; i++){
                    String subsekvens = biter[i] + biter[i+1] + biter[i+2];     
                    Boolean eksisterer = false;
                    
                    if(subsekvenser.containsKey(subsekvens)){
                            eksisterer = true;
                    }

                    if(!eksisterer){
                        Subsekvens nySubsekvens = new Subsekvens(subsekvens);
                        nySubsekvens.oekAntall(1);
                        subsekvenser.put(subsekvens, nySubsekvens);
                }
            }
        }
    }

    settInnHashMap(subsekvenser);
    return subsekvenser;

    }

    public HashMap<String,Subsekvens> hentFlette(){
        return hashBeholder.get(0);
    }
    
    public ArrayList<HashMap> hentHashBeholder(){
        return hashBeholder;
    }

    public void fjernMap(int index){
        hashBeholder.remove(index);
    }

    public HashMap<String,Subsekvens> hentMap(int index){
        return hashBeholder.get(index);
    }

    public int hentAntMaps(){
        return hashBeholder.size();
    }

    //Enkel metode for fletting av HashMaps. Her slaas to HashMaps sammen som er argument for metoden. Resultatet av flettingen returneres.

    public static HashMap fletting(HashMap<String, Subsekvens> en, HashMap<String,Subsekvens> to){

        HashMap<String,Subsekvens> sammenslått = new HashMap<>();

        try {
            
            for(Entry<String, Subsekvens> entry : en.entrySet()){
                String key = entry.getKey();
                Subsekvens value = entry.getValue();
                sammenslått.put(key,value);
            }
            
            for(Entry<String,Subsekvens> entry : to.entrySet()){
                String key = entry.getKey();
                Subsekvens value = entry.getValue();

                if(sammenslått.containsKey(key)){
                    sammenslått.get(key).oekAntall(1);

                } else if(!sammenslått.containsKey(key)){
                    sammenslått.put(key,value);
                }
            }

        } 

        catch (IndexOutOfBoundsException e) {

           
           return sammenslått;        

        }
        
        return sammenslått;   
    } 
}
