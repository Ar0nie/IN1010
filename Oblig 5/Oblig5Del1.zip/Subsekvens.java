//Klassen Subsekvens med et utvalg av instansvariabler og metoder.

public class Subsekvens {

    public final String subsekvens;
    private int antall = 0;

    public Subsekvens(String subsekvens){
        this.subsekvens = subsekvens;
    }

    public int hentAntall(){
        return antall;
    }

    public void oekAntall(int i){
        antall+= i;
    }

    public String toString(){
        return "(" + subsekvens + "," + antall + ")";
    }
}