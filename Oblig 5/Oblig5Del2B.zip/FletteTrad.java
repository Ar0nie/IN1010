import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.CountDownLatch;

//Den kjørbare Traad klassen FletteTrad, som overtar funksjonaliteten for fletting av to ulike hashmaps.

public class FletteTrad implements Runnable{
    
    private Monitor2 monitor;
    private CountDownLatch minBarriere;

    //Konstruktør med tilhørende instansvariabler.

    public FletteTrad(Monitor2 monitor, CountDownLatch minBarriere){
        this.monitor = monitor;
        this.minBarriere = minBarriere;
    }

    //Run metode som for hver trad vil kjøre dersom resultatet av meotden hentUtTo ikke er null. Hver gjennomkjøring vil bidra til å fjerne countDownLatchen i main traaden.

    public void run(){
        ArrayList<HashMap<String,Subsekvens>> slaaSammen = monitor.hentUtTo();
        while(slaaSammen != null){
        HashMap<String,Subsekvens> en = slaaSammen.get(0);
        HashMap<String,Subsekvens> to = slaaSammen.get(1);

        HashMap<String,Subsekvens> nyFlette = en;

        for(String key: to.keySet()){
            if(nyFlette.containsKey(key)){
                nyFlette.get(key).oekAntall(to.get(key).hentAntall());
            } else {
                nyFlette.put(key, to.get(key));
            }
        }

        monitor.settInnHashMap(nyFlette);
        monitor.signaliserFerdig();
        System.out.println("Filer sammenslatt..");
        minBarriere.countDown();
        slaaSammen = monitor.hentUtTo();

    }
    }
}