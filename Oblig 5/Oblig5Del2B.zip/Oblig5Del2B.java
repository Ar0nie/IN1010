import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Map.Entry;
import java.util.concurrent.CountDownLatch;

//Main traader Oblig5Del2B.

public class Oblig5Del2B {
    
    public static void main(String[] args) throws FileNotFoundException {
        
        String mappe;
        mappe = args[0];
        String fil = "";
        String linje = "";
        Scanner sc = new Scanner(new File(mappe + "/" + "metadata.csv"));
        File filerIMappe = new File(mappe);
        File[] filListe = filerIMappe.listFiles();

        int filerSomSkalLesesInn = filListe.length - 1;
        int antallFlettinger = filListe.length - 2;
        
        System.out.println("Antall filer aa lese inn: " + filerSomSkalLesesInn);
        System.out.println("Antall flettinger: " + antallFlettinger);

        SubsekvensRegister register = new SubsekvensRegister();
        Monitor2 monitor = new Monitor2(register,filerSomSkalLesesInn + antallFlettinger);

        CountDownLatch innlesingLatch = new CountDownLatch(filerSomSkalLesesInn);
        CountDownLatch fletteLatch = new CountDownLatch(antallFlettinger);
        
        //Leser inn filer

        while(sc.hasNextLine()){
            linje = sc.nextLine();
            String[] biter = linje.strip().split(",");
            fil = (mappe + "/" + biter[0]);
            LeseTrad filLeser = new LeseTrad(fil, monitor, innlesingLatch);
            Thread nyTraad = new Thread(filLeser);
            nyTraad.start();
        }

        //Fletter
        
        for(int i = 0; i < antallFlettinger; i++){
            Thread t = new Thread(new FletteTrad(monitor, fletteLatch));
            t.start();
        }
        
        //Barriere som vil gi tilbakemelding til brukeren om ferdig gjennomkjøring av filer.

        try  {
            innlesingLatch.await();
            fletteLatch.await();
        } catch(InterruptedException e){
            System.out.println("Avbrutt");
            System.exit(-1);
        }

        System.out.println("Alle filer lest inn!");
        System.out.println("Alle HashMaps flettet!");
        System.out.println();
        
        HashMap<String,Subsekvens> flette = monitor.hentFlette();
        Subsekvens flest = new Subsekvens("ABC");
        

        // Itererer igjennom fletten og sammenligner med en vilkårlig subsekvens "ABC", som ikke er del av fletten. Da finner vi ut av hvilken subsekvens som forekommer flest ganger.
        
        for(Entry<String, Subsekvens> entry : flette.entrySet()){
            Subsekvens value = entry.getValue();
            int ant = value.hentAntall();
            if(ant > flest.hentAntall()){
                flest = value;
            }
        }

        System.out.println("Subsekvensen med flest forekomster i mappen: " + mappe + ", er: " + flest);
        System.exit(-1);

    }
}