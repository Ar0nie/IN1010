import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Oblig6 {
    
    public static void main(String[] args) throws FileNotFoundException {
       String filnavn = args[0];
       File fil = new File(filnavn);
       Labyrint labyrint = new Labyrint(fil);
       System.out.println(labyrint);

       Scanner sc = new Scanner(System.in);
       System.out.println("Skriv inn koordinater <rad> <kolonne> ('-1' for aa avslutte");
       String input = sc.nextLine();
       String[] inputs = input.split(" ");
       int rad = Integer.parseInt(inputs[0]);

       if(rad == -1){
           System.exit(-1);
       }
       int kolonne = Integer.parseInt(inputs[1]);

       while(rad != -1){
        try{

        
        labyrint.finnUtveiFra(rad, kolonne);
        System.out.println("Skriv inn nye koordinater('-1' for aa avslutte)");
        input = sc.nextLine();
        inputs = input.split(" ");
        rad = Integer.parseInt(inputs[0]);
        
        if(rad != -1){
            kolonne = Integer.parseInt(inputs[1]);
        }
       } catch (IndexOutOfBoundsException e){
           System.out.println("Ugyldig input!");
           System.exit(-1);
       }
    }
}
}
