public abstract class Rute {
    
    public int x;
    public int y;
    Labyrint labyrint;
    Rute[] naboer;
    public Rute forrige;
    public static Rute start;

    public Rute(int x, int y, Labyrint labyrint){
        this.x = x;
        this.y = y;
        this.labyrint = labyrint;
        this.naboer = new Rute[4];
    }

    public void settNaboer(Rute[] naboer){
        for(int i = 0; i < 4; i++){
            this.naboer[i] = naboer[i];
        }
    }

    abstract public void finn(Rute fra);

    public void settStart(Rute start){
        this.start = start;
    }
    
    public void settForigge(Rute forrige){
        this.forrige = forrige;
    }

    public String tostring(){
        String str = "";
        str +=  "Naboer: ";
        for(Rute rute : naboer){
            if(rute != null){
                str += "(" + rute.x + "," + rute.y + ")";
            }
        }

        str += "|";
        return str;

    }
}
