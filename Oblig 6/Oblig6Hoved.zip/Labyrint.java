import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Labyrint{

    private Rute[][] labyrint;
    
    public Labyrint(File fil) throws FileNotFoundException{
        labyrint = lesFraFil(fil);
    }

    private Rute[][] lesFraFil(File fil)throws FileNotFoundException{

        //deklarasjon av nodvendige variabler
        Rute[][] labyrint;
        Scanner sc = new Scanner(fil);
        int antallKolonner;
        int antallRader;
        Rute[][][] naboer;
        char[] tegn;
        
        //Inndeling av flere nodvendige variabler.
        antallRader = sc.nextInt();
        antallKolonner = sc.nextInt();
        sc.nextLine();
        labyrint = new Rute[antallKolonner][antallRader];
        naboer = new Rute[antallKolonner][antallRader][4];

        //Legg inn ruter i rutenettet
        for(int y = 0; y < antallRader; y++){
            tegn = sc.nextLine().toCharArray();
            for(int x = 0; x < antallKolonner; x++){
                if(tegn[x] == '#'){
                    labyrint[x][y] = new SortRute(x,y,this);
                } else if((x == 0 || x == antallKolonner - 1 || y == 0 || y == antallRader - 1) && tegn[x] == '.'){
                    labyrint[x][y] = new Aapning(x,y,this);
                    
                } else if(tegn[x] == '.'){
                    labyrint[x][y] = new HvitRute(x,y,this);
                }
            }
        }

        //Tilordner naboer i en array og setter naboer for rute avslutningsvis.

        boolean erVenstre, erHoyre, erOver, erUnder;
        
        for(int x = 0; x < antallKolonner; x++){
            if(x == 0){
                erVenstre = false;
            } else {
                erVenstre = true;
            }

            if(x == antallKolonner - 1){
                erHoyre = false;
            } else {
                erHoyre = true;
            }

            for(int y = 0; y < antallRader; y++){
                if(y == 0){
                    erOver = false;
                } else {
                    erOver = true;
                }

                if(y == antallRader - 1){
                    erUnder = false;
                } else {
                    erUnder = true;
                }

                if(erHoyre){
                    naboer[x][y][0] = labyrint[x+1][y];
                }
                if(erVenstre){
                    naboer[x][y][2] = labyrint[x-1][y];
                }
                if(erUnder){
                    naboer[x][y][1] = labyrint[x][y+1];
                }
                if(erOver){
                    naboer[x][y][3] = labyrint[x][y-1];
                }
                labyrint[x][y].settNaboer(naboer[x][y]);
            }
        }
        //Ferdig labyrint

        return labyrint;
    }

    //Forste metodekall for finnUtveiFra, laget en metode settStart og settForrige i rute klassen for at hver rute skal hvite hvilken rute den kom fra for et kall.

    public void finnUtveiFra(int rad, int kol){
        labyrint[kol][rad].settStart(labyrint[kol][rad]);
        labyrint[kol][rad].finn(null);
    }

    public String toString(){
        String str = "";
        for(int y = 0; y < labyrint[0].length; y++){
            for(int x = 0; x < labyrint.length; x++){
                str += labyrint[x][y].toString();
            }
            str += "\n";
        }
        return str;

    }
}