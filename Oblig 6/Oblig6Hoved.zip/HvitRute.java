public class HvitRute extends Rute {

    public HvitRute(int x,int y, Labyrint labyrint){
        super(x, y, labyrint);
    }

    @Override
    public String toString(){
        return ".";
    }

    public void finn(Rute fra){
        if(fra == null){
            for(Rute nabo : naboer){
                nabo.settForigge(start);
                nabo.finn(nabo);
            }
        } else {
           for(Rute nabo : naboer){
               if(!(nabo.x == forrige.x && nabo.y == forrige.y)){
                nabo.settForigge(fra);
                nabo.finn(nabo);
               }
           }
        }
    }
}

