public class Aapning extends HvitRute {
    
    public Aapning(int x,int y, Labyrint labyrint){
        super(x, y, labyrint);
    }

    
    public void finn(Rute fra){
        if(fra == null){
            System.out.println("Fant aapning! " + "(" + start.y + "," + start.x  + ")");
            for(Rute nabo : naboer){
                if(nabo != null){
                    nabo.settForigge(start);
                    nabo.finn(nabo);
                }
            }
            
        } else {
            System.out.println("Fant aapning! " + "(" + fra.y + "," + fra.x  + ")");
        }
    }
}
