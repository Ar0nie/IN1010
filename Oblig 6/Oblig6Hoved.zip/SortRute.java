public class SortRute extends Rute {
    

    public SortRute(int x, int y, Labyrint labyrint){
        super(x,y,labyrint);
    }

    @Override
    public String toString(){
        return "#";
    }

    public void finn(Rute fra){
        if(fra == null){
            System.out.println("Kan ikke starte paa sort ");
        } else  {
            return;
        }
    }
}
